import os
import io
import asyncio
import json
import re
import logging
from PIL import Image, ImageOps
from google import genai
from google.genai import types

client = genai.Client(api_key=os.getenv("GEMINI_API_KEY") or "DUMMY_KEY")
MODEL = "gemini-2.5-flash"

async def analyze_prescription_ai(text: str, language: str = "en", image_bytes: bytes = None) -> dict:
    """
    Analyzes prescription document using Gemini Multimodal AI.
    Accepts OCR text and optional image_bytes for vision analysis.
    """
    lang_map = {
        "hi": "Hindi",
        "kn": "Kannada",
        "ta": "Tamil",
        "ml": "Malayalam",
        "te": "Telugu",
        "en": "English"
    }
    target_lang = lang_map.get(language, "English")

    prompt = f"""
You are an expert medical AI assistant. Analyze this uploaded prescription image and OCR text.

OCR EXTRACTED TEXT (if available):
{text if text else "None"}

LANGUAGES REQUIREMENT:
- The fields "verified_text", "explanation", and "precautions" MUST be written in {target_lang}.
- All medicine names, generic names, duration, timing, and reminder_times must remain in English.

TASK 1: PRESCRIPTION VALIDATION
Determine if this image/text is a VALID MEDICAL PRESCRIPTION containing doctor-prescribed medications (tablets, capsules, syrups, injections, eye drops, ointments, or standard pharmaceutical drug names with dosages/instructions).
Ignore non-medical objects, selfies, animals, cars, food menus, homework, general notes, or non-prescription bills.

IF NOT A VALID PRESCRIPTION:
Set "is_valid_prescription": false
Set "explanation": "This image doesn't seem to be a prescription.\nTry uploading:\n\n📄 A doctor's prescription\n📸 A clear, well-lit photo\n📑 A single prescription page"
Set "medicines": [], "schedule": [], "precautions": []

TASK 2: MEDICINE EXTRACTION & ANALYSIS (If valid prescription)
1. Set "is_valid_prescription": true
2. Extract all valid prescribed medications into "medicines" array (Brand Name "medicine", Generic Name "generic").
3. Extract structured dosage schedule into "schedule" array:
   - "medicine": Brand/Commercial Name
   - "dosage": Dosage pattern (e.g. "1-0-1", "Once daily", "1 tablet")
   - "duration": Course duration (e.g. "5 days", "1 week", "As needed")
   - "timing": Instruction (e.g. "After Food", "Before Food")
   - "reminder_times": List of HH:MM 24-hour notification times based on dosage:
     - "1-0-0" -> ["08:00"]
     - "0-1-0" -> ["13:00"]
     - "0-0-1" -> ["20:00"]
     - "1-0-1" -> ["08:00", "20:00"]
     - "1-1-1" -> ["08:00", "14:00", "20:00"]
     - Default if unspecified -> ["08:00"]
4. Write a simple, patient-friendly summary in {target_lang} under "explanation". Keep medical disclaimer at the bottom.
5. Provide key precautions in {target_lang} under "precautions".

CONSTRAINTS:
- Do NOT include doctor contact numbers, hospital address, patient address, or emails.
- Return raw JSON ONLY without markdown wrapping (no ```json).

JSON FORMAT:
{{
    "is_valid_prescription": true,
    "verified_text": "...",
    "medicines": [
        {{"medicine": "Dolo 650", "generic": "Paracetamol"}}
    ],
    "schedule": [
        {{
            "medicine": "Dolo 650",
            "dosage": "1-0-1",
            "duration": "5 days",
            "timing": "After Food",
            "reminder_times": ["08:00", "20:00"]
        }}
    ],
    "explanation": "...",
    "precautions": ["..."]
}}
"""

    contents = []
    if image_bytes and len(image_bytes) > 100:
        try:
            pil_img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
            try:
                pil_img = ImageOps.exif_transpose(pil_img)
            except Exception:
                pass
            contents.append(pil_img)
        except Exception as ie:
            logging.warning(f"Could not load image bytes into PIL: {ie}")

    contents.append(prompt)

    def _generate():
        config = types.GenerateContentConfig(
            response_mime_type="application/json",
            temperature=0.1,
            max_output_tokens=1024,
            thinking_config=types.ThinkingConfig(thinking_budget=0),
        )
        response = client.models.generate_content(
            model=MODEL,
            contents=contents,
            config=config,
        )

        raw_text = response.text.strip() if hasattr(response, "text") and response.text else ""
        raw_text = re.sub(r"^```json\s*", "", raw_text, flags=re.IGNORECASE)
        raw_text = re.sub(r"^```\s*", "", raw_text, flags=re.IGNORECASE)
        raw_text = re.sub(r"\s*```$", "", raw_text, flags=re.IGNORECASE)

        try:
            parsed = json.loads(raw_text)
            if not isinstance(parsed, dict):
                parsed = {}

            # Ensure expected fields exist
            for k in ["is_valid_prescription", "verified_text", "medicines", "schedule", "explanation", "precautions"]:
                if k not in parsed:
                    if k == "is_valid_prescription":
                        parsed[k] = False
                    elif k in ["medicines", "schedule", "precautions"]:
                        parsed[k] = []
                    else:
                        parsed[k] = ""

            # Populate medicines from schedule if medicines list is empty
            if not parsed.get("medicines") and parsed.get("schedule"):
                parsed["medicines"] = [
                    {"medicine": s.get("medicine", "Prescribed Medication"), "generic": "Prescribed Medication"}
                    for s in parsed["schedule"] if isinstance(s, dict) and s.get("medicine")
                ]

            if parsed.get("medicines") or parsed.get("schedule"):
                parsed["is_valid_prescription"] = True

            return parsed
        except Exception as err:
            logging.error(f"Failed to parse Gemini response JSON: {err}")
            return {
                "is_valid_prescription": False,
                "verified_text": text or "",
                "medicines": [],
                "schedule": [],
                "explanation": "This image doesn't seem to be a prescription.",
                "precautions": []
            }

    return await asyncio.to_thread(_generate)
