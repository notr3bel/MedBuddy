import logging
import asyncio
from typing import Optional
from app.services.supabase_client import supabase

logger = logging.getLogger("medintel.reminders")

# In-memory storage fallback when Supabase table is absent or unreachable
_in_memory_schedules: dict[str, list[dict]] = {}
_in_memory_dose_logs: list[dict] = []

def generate_reminder_times(dosage: str) -> list[str]:
    dosage = dosage.strip()
    mapping = {
        "1-0-0": ["08:00"],
        "0-1-0": ["14:00"],
        "0-0-1": ["20:00"],
        "1-0-1": ["08:00", "20:00"],
        "1-1-0": ["08:00", "14:00"],
        "0-1-1": ["14:00", "20:00"],
        "1-1-1": ["08:00", "14:00", "20:00"]
    }
    return mapping.get(dosage, ["08:00"])

async def save_user_reminder_schedule(
    user_id: str,
    schedules: list[dict],
    timezone: str = "Asia/Kolkata",
    prescription_id: Optional[str] = None
) -> dict:
    if not user_id:
        return {"success": False, "error": "user_id is required"}

    # Update in-memory fallback
    _in_memory_schedules[user_id] = schedules

    if supabase:
        try:
            records = []
            for item in schedules:
                records.append({
                    "user_id": user_id,
                    "medicine_name": item.get("medicine_name", item.get("medicine", "Medicine")),
                    "dosage": item.get("dosage", "1-0-0"),
                    "reminder_times": item.get("reminder_times", generate_reminder_times(item.get("dosage", ""))),
                    "timezone": timezone,
                    "prescription_id": prescription_id
                })
            def _insert():
                return supabase.table("medication_schedules").upsert(records).execute()
            await asyncio.to_thread(_insert)
        except Exception as e:
            logger.warning(f"Supabase schedule save fallback to in-memory: {e}")

    return {
        "success": True,
        "message": f"Saved {len(schedules)} medication schedules for user {user_id}."
    }

async def get_user_reminder_schedules(user_id: str) -> list[dict]:
    if not user_id:
        return []

    if supabase:
        try:
            def _fetch():
                res = supabase.table("medication_schedules").select("*").eq("user_id", user_id).execute()
                return res.data or []
            db_schedules = await asyncio.to_thread(_fetch)
            if db_schedules:
                return db_schedules
        except Exception as e:
            logger.warning(f"Supabase fetch schedules fallback: {e}")

    return _in_memory_schedules.get(user_id, [])

async def log_dose_action(
    user_id: str,
    schedule_id: str,
    medicine_name: str,
    status: str,
    scheduled_time: str,
    logged_at: Optional[str] = None
) -> dict:
    log_entry = {
        "user_id": user_id,
        "schedule_id": schedule_id,
        "medicine_name": medicine_name,
        "status": status,
        "scheduled_time": scheduled_time,
        "logged_at": logged_at
    }
    _in_memory_dose_logs.append(log_entry)

    if supabase:
        try:
            def _log():
                supabase.table("dose_logs").insert(log_entry).execute()
            await asyncio.to_thread(_log)
        except Exception as e:
            logger.warning(f"Supabase dose log fallback: {e}")

    return {
        "success": True,
        "message": f"Dose status '{status}' recorded for {medicine_name}."
    }

async def get_medication_dashboard(user_id: str, date: Optional[str] = None) -> dict:
    schedules = await get_user_reminder_schedules(user_id)
    user_logs = [log for log in _in_memory_dose_logs if log.get("user_id") == user_id]

    taken_count = sum(1 for l in user_logs if l.get("status") == "Taken")
    skipped_count = sum(1 for l in user_logs if l.get("status") == "Skipped")
    total_logged = len(user_logs)
    adherence_rate = round((taken_count / total_logged * 100), 1) if total_logged > 0 else 100.0

    return {
        "success": True,
        "date": date,
        "total_medicines": len(schedules),
        "schedules": schedules,
        "adherence_rate": adherence_rate,
        "dose_stats": {
            "taken": taken_count,
            "skipped": skipped_count,
            "total_logged": total_logged
        }
    }
