def sanitize_prescription_schedule(schedule_list: list[dict]) -> list[dict]:
    """
    Phase 7: Validates prescription fields (Medicine Name, Strength, Dosage, Frequency, Duration, Timing, Instructions).
    Replaces any missing, null, or ambiguous field with 'Unknown' instead of guessing or fabricating.
    """
    sanitized_schedule = []

    for entry in schedule_list:
        medicine_name = entry.get("medicine", "").strip() or "Unknown"
        dosage = entry.get("dosage", "").strip() or "Unknown"
        duration = entry.get("duration", "").strip() or "Unknown"
        timing = entry.get("timing", "").strip() or "Unknown"
        instructions = entry.get("instructions", "").strip() or "Unknown"
        reminder_times = entry.get("reminder_times", [])

        # Ensure reminder_times is valid list
        if not isinstance(reminder_times, list) or len(reminder_times) == 0:
            if dosage != "Unknown":
                reminder_times = ["08:00"]
            else:
                reminder_times = []

        sanitized_schedule.append({
            "medicine": medicine_name,
            "dosage": dosage if dosage != "" else "Unknown",
            "duration": duration if duration != "" else "Unknown",
            "timing": timing if timing != "" else "Unknown",
            "instructions": instructions if instructions != "" else "Unknown",
            "reminder_times": reminder_times
        })

    return sanitized_schedule
