import os
import io
import asyncio
import json
import re
import logging
from PIL import Image, ImageOps
from google import genai
from google.genai import types

client = genai.Client(api_key=os.getenv("GEMINI_API_KEY") or "DUMMY_KEY")
MODEL = "gemini-2.5-flash"

async def summarize_medical_report(report_text: str, language: str = "en", image_bytes: bytes = None) -> dict:
    """
    Analyzes medical report using Gemini Multimodal AI Vision.
    Accepts OCR text and optional image_bytes for vision analysis.
    """
    lang_map = {
        "hi": "Hindi",
        "kn": "Kannada",
        "ta": "Tamil",
        "ml": "Malayalam",
        "te": "Telugu",
        "en": "English"
    }
    target_lang = lang_map.get(language, "English")

    prompt = f"""
You are an expert medical report analyzer AI. Analyze this uploaded medical report image and OCR text.

OCR EXTRACTED TEXT (if available):
{report_text if report_text else "None"}

LANGUAGES REQUIREMENT:
- The "summary" field MUST be written in {target_lang}.

TASK 1: REPORT VALIDATION & CLASSIFICATION
Determine if this image/text is a VALID MEDICAL REPORT or LAB TEST / RADIOLOGY / PATHOLOGY / CLINICAL FINDINGS REPORT (e.g. Blood Test, CBC, LFT, KFT, Lipid, HbA1c, Thyroid, Urine, MRI, CT, X-ray, ECG, Echo, Discharge Summary, Biopsy, Pathology Report, Doctor Note).
Ignore non-medical objects, selfies, animals, cars, food menus, homework, general notes, or prescriptions.

IF NOT A VALID MEDICAL REPORT:
Set "is_valid_report": false
Set "summary": "This image doesn't seem to be a report.\nTry uploading:\n\n📄 A doctor's report\n📸 A clear, well-lit photo\n📑 A single report page"
Set "abnormal_count": 0
Set "report_type": "Unknown Report"

TASK 2: REPORT SUMMARIZATION (If valid medical report)
1. Set "is_valid_report": true
2. Identify the report category as "report_type" (e.g. "CBC", "LFT", "KFT", "Lipid", "HbA1c", "Thyroid", "Urine", "MRI", "CT", "X-ray", "ECG", "Echo", or "Lab Report").
3. Count the total number of abnormal/out-of-range results as an integer "abnormal_count".
4. Provide a well-structured, clear markdown summary in {target_lang} as "summary":
   - Health Status Overview (Normal/Abnormal status)
   - Key Findings (Main test values, reference ranges, abnormal indicators with ⚠️ Warning)
   - Suggestions & Next Steps (Consult doctor, follow-up tests)

CONSTRAINTS:
- Do NOT include patient address, doctor phone number, or administrative emails.
- Return raw JSON ONLY without markdown code blocks (no ```json).

JSON STRUCTURE:
{{
    "is_valid_report": true,
    "report_type": "CBC",
    "abnormal_count": 1,
    "summary": "### Health Status Overview\\n..."
}}
"""

    contents = []
    if image_bytes and len(image_bytes) > 100:
        try:
            pil_img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
            try:
                pil_img = ImageOps.exif_transpose(pil_img)
            except Exception:
                pass
            contents.append(pil_img)
        except Exception as ie:
            logging.warning(f"Could not load report image bytes into PIL: {ie}")

    contents.append(prompt)

    def _generate() -> dict:
        config = types.GenerateContentConfig(
            response_mime_type="application/json",
            temperature=0.1,
            max_output_tokens=1024,
            thinking_config=types.ThinkingConfig(thinking_budget=0),
        )
        response = client.models.generate_content(
            model=MODEL,
            contents=contents,
            config=config,
        )

        text = response.text.strip() if hasattr(response, "text") and response.text else ""
        text = re.sub(r"^```json\s*", "", text, flags=re.IGNORECASE)
        text = re.sub(r"^```\s*", "", text, flags=re.IGNORECASE)
        text = re.sub(r"\s*```$", "", text, flags=re.IGNORECASE)

        try:
            parsed = json.loads(text)
            if not isinstance(parsed, dict):
                parsed = {}

            if "is_valid_report" not in parsed:
                parsed["is_valid_report"] = bool(parsed.get("summary") and "doesn't seem to be a report" not in str(parsed.get("summary")))

            if "summary" not in parsed:
                parsed["summary"] = text
            if "abnormal_count" not in parsed:
                parsed["abnormal_count"] = 0
            if "report_type" not in parsed:
                parsed["report_type"] = "Medical Report"

            return parsed
        except Exception as err:
            logging.error(f"Failed to parse Gemini report response: {err}")
            return {
                "is_valid_report": False,
                "summary": "This image doesn't seem to be a report.\nTry uploading:\n\n📄 A doctor's report\n📸 A clear, well-lit photo\n📑 A single report page",
                "abnormal_count": 0,
                "report_type": "Unknown Report"
            }

    return await asyncio.to_thread(_generate)
